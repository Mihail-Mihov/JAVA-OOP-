import zoo.*;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        Reptile reptile = new Reptile("pesho");
        Gorilla gorilla = new Gorilla("as");
        Lizard lizard = new Lizard("asd");

    }
}
