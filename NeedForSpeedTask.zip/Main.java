import vehicle.CrossMotorcycle;
import vehicle.Vehicle;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        

    }
}
