import animals.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        List<Animal> animalList = new ArrayList<>();

        String input = scanner.nextLine();

        while (!"Beast!".equals(input)){
            String animalType = input;
            String[] data = scanner.nextLine().split(" ");
            String name = data[0];
            int age = Integer.parseInt(data[1]);
            String gender = data[2];

            Animal animal;

            try {


                if (animalType.equals("Cat")) {
                    animal = new Cat(name, age, gender);
                } else if (animalType.equals("Dog")) {
                    animal = new Dog(name, age, gender);
                } else if (animalType.equals("Frog")) {
                    animal = new Frog(name, age, gender);
                } else if (animalType.equals("Kitten")) {
                    animal = new Kitten(name, age);
                } else {
                    animal = new Tomcat(name, age);
                }
                animalList.add(animal);
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
            }


            input = scanner.nextLine();
        }

        for (Animal animal : animalList) {
            System.out.println(animal);
        }
    }
}
