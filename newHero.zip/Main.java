
import hero.DarkKnight;
import hero.Hero;
import hero.MuseElf;
import hero.SoulMaster;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        MuseElf museElf = new MuseElf("pesho", 12);

        SoulMaster soulMaster = new SoulMaster("peshp", 76);

        System.out.println(soulMaster);
        Hero hero = new Hero("Hero",12);
        System.out.println(hero);



    }
}
